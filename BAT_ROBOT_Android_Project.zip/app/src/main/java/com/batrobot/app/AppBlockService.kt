package com.batrobot.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import android.view.Gravity
import android.graphics.Color
import android.graphics.PixelFormat
import android.widget.LinearLayout
import android.widget.TextView
import android.content.Intent
import android.provider.Settings
import android.os.Handler
import android.os.Looper
import android.view.View

class AppBlockService : AccessibilityService() {
    private var blocker: View? = null
    private val handler = Handler(Looper.getMainLooper())

    // Android deliberately keeps Settings and the dialer reachable for recovery and emergencies.
    private val safePackages = setOf(
        "com.android.settings", "com.android.phone", "com.android.dialer",
        "com.google.android.dialer", "com.samsung.android.dialer",
        "com.samsung.android.incallui", "com.android.emergency",
        "com.batrobot.app"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val prefs = getSharedPreferences("bat_robot", MODE_PRIVATE)
        val until = prefs.getLong("lock_until", 0L)
        if (until <= System.currentTimeMillis()) {
            prefs.edit().remove("lock_until").apply()
            removeBlocker()
            return
        }
        if (safePackages.contains(pkg)) { removeBlocker(); return }

        // Selected-app filtering is intentionally not claimed in this starter build.
        // "all" mode blocks ordinary foreground apps; selected mode is a timer-only preview.
        val mode = prefs.getString("mode", "selected")
        if (mode == "all") showBlocker(until) else removeBlocker()
    }

    private fun showBlocker(until: Long) {
        if (blocker != null) return
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32,32,32,32)
            setBackgroundColor(Color.rgb(16,16,16))
        }
        panel.addView(TextView(this).apply {
            text = "🤖  BAT ROBOT"
            textSize = 28f; setTextColor(Color.rgb(239,68,68)); gravity=Gravity.CENTER
        })
        val countdown = TextView(this).apply {
            textSize=20f; setTextColor(Color.WHITE); gravity=Gravity.CENTER
            setPadding(0,24,0,24)
        }
        panel.addView(countdown)
        panel.addView(TextView(this).apply {
            text="این برنامه در مدت تمرکز محدود شده است."
            textSize=16f; setTextColor(Color.LTGRAY); gravity=Gravity.CENTER
        })
        val dial = TextView(this).apply {
            text="تماس اضطراری"; textSize=18f; gravity=Gravity.CENTER
            setTextColor(Color.WHITE); setPadding(20,32,20,20)
            setOnClickListener {
                try { startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (_: Exception) {}
            }
        }
        panel.addView(dial)
        blocker = panel
        val params = LayoutParams(
            LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT,
            LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            LayoutParams.FLAG_LAYOUT_IN_SCREEN or LayoutParams.FLAG_FULLSCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity=Gravity.TOP or Gravity.START }
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).addView(panel,params) }
        catch (_: Exception) { blocker=null; return }

        val tick = object : Runnable {
            override fun run() {
                val left = until-System.currentTimeMillis()
                if (left <= 0) { removeBlocker(); return }
                val s=left/1000
                countdown.text="زمان باقی‌مانده\n%02d:%02d:%02d".format(s/3600,(s%3600)/60,s%60)
                handler.postDelayed(this,1000)
            }
        }
        handler.post(tick)
    }

    private fun removeBlocker() {
        handler.removeCallbacksAndMessages(null)
        val old=blocker ?: return
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(old) } catch (_: Exception) {}
        blocker=null
    }
    override fun onInterrupt() { removeBlocker() }
    override fun onDestroy() { removeBlocker(); super.onDestroy() }
}
