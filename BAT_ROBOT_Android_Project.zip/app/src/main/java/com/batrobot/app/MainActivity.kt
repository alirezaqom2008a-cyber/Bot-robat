package com.batrobot.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.text.InputType
import android.content.Context

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("bat_robot", Context.MODE_PRIVATE) }
    private var mode = "selected"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,16,16)
        window.navigationBarColor = Color.rgb(16,16,16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 34, 28, 24)
            setBackgroundColor(Color.rgb(16,16,16))
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE): TextView =
            TextView(this).apply { this.text=text; textSize=size; setTextColor(color); gravity=Gravity.CENTER }
        root.addView(label("🤖", 54f))
        root.addView(label("BAT ROBOT", 30f, Color.rgb(239,68,68)))
        root.addView(label("کنترل زمان استفاده از گوشی", 15f, Color.LTGRAY))
        val status = label("", 15f, Color.rgb(120,220,140))
        status.setPadding(0,24,0,12)
        root.addView(status)

        root.addView(label("حالت محدودیت", 18f))
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL; setPadding(8,8,8,8) }
        val selected = RadioButton(this).apply { text="فقط برنامه‌های انتخابی (نسخه پایه: فهرست انتخاب در نسخه بعدی)"; setTextColor(Color.WHITE); id=1 }
        val full = RadioButton(this).apply { text="حالت گسترده (برنامه‌های معمولی)"; setTextColor(Color.WHITE); id=2 }
        group.addView(selected); group.addView(full); selected.isChecked=true
        group.setOnCheckedChangeListener { _, id -> mode = if(id==2) "all" else "selected" }
        root.addView(group)

        root.addView(label("مدت محدودیت (دقیقه)", 17f))
        val duration = EditText(this).apply {
            setText("60"); inputType=InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); gravity=Gravity.CENTER
            hint="مثلاً 60"; setPadding(12,12,12,12)
        }
        root.addView(duration, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val start = Button(this).apply {
            text="شروع محدودیت"; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(190,35,35))
        }
        root.addView(start, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 58).apply { topMargin=22 })
        val access = Button(this).apply { text="فعال‌کردن دسترسی لازم" }
        root.addView(access)
        access.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        val emergency = Button(this).apply { text="تماس اضطراری"; setBackgroundColor(Color.DKGRAY); setTextColor(Color.WHITE) }
        root.addView(emergency)
        emergency.setOnClickListener {
            try { startActivity(Intent(Intent.ACTION_DIAL)) }
            catch (_: Exception) { Toast.makeText(this,"امکان بازکردن شماره‌گیر نیست",Toast.LENGTH_SHORT).show() }
        }

        start.setOnClickListener {
            val mins = duration.text.toString().toLongOrNull()
            if (mins == null || mins !in 1..1440) {
                Toast.makeText(this,"مدت باید بین ۱ تا ۱۴۴۰ دقیقه باشد",Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val until = System.currentTimeMillis() + mins*60_000L
            prefs.edit().putLong("lock_until",until).putString("mode",mode).apply()
            status.text = "محدودیت فعال شد • ${mins} دقیقه"
            Toast.makeText(this,"زمان‌بندی ذخیره شد. سرویس دسترس‌پذیری باید روشن باشد.",Toast.LENGTH_LONG).show()
        }
        val until = prefs.getLong("lock_until",0L)
        status.text = if(until > System.currentTimeMillis()) "زمان‌بندی ذخیره‌شده فعال است" else "آماده"
        setContentView(root)
    }
}
